Jonas R. Atienza
2020-03270

I have learned how to write a GUI for R programs

I wish programming GUI for R was discussed in the laboratory

Thank you sir!